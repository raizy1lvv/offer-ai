#!/usr/bin/env python3
"""
Cleanup script — deletes videos older than 30 days.
Add to cron: 0 2 * * * /path/to/cleanup.py
"""
import os
import sqlite3
import time
from datetime import datetime, timedelta

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
VIDEOS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "storage", "videos")
DB_PATH = os.path.join(DATA_DIR, "interviewer.db")
DAYS_KEEP = 30

def cleanup():
    print(f"[{datetime.now().isoformat()}] Starting cleanup (keep {DAYS_KEEP} days)")
    
    cutoff = datetime.now() - timedelta(days=DAYS_KEEP)
    deleted_files = 0
    freed_bytes = 0
    
    # Delete old video files
    if os.path.exists(VIDEOS_DIR):
        for fname in os.listdir(VIDEOS_DIR):
            fpath = os.path.join(VIDEOS_DIR, fname)
            if os.path.isfile(fpath):
                mtime = datetime.fromtimestamp(os.path.getmtime(fpath))
                if mtime < cutoff:
                    size = os.path.getsize(fpath)
                    os.remove(fpath)
                    deleted_files += 1
                    freed_bytes += size
                    print(f"  Deleted: {fname}")
    
    # Mark sessions as having no video
    if os.path.exists(DB_PATH):
        conn = sqlite3.connect(DB_PATH)
        conn.execute(
            "UPDATE sessions SET video_path=NULL WHERE video_path IS NOT NULL AND finished_at < ?",
            (cutoff.isoformat(),)
        )
        conn.commit()
        conn.close()
    
    print(f"Done: {deleted_files} files deleted, {freed_bytes / 1024 / 1024:.1f} MB freed")

if __name__ == "__main__":
    cleanup()

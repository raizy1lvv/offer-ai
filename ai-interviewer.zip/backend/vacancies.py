from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import List, Optional
import httpx
import json
import os
from database import get_db_connection
from auth import get_current_user

router = APIRouter()

class VacancyCreate(BaseModel):
    title: str
    description: Optional[str] = ""
    time_per_question: int = 60
    proctor_face: bool = True
    proctor_audio: bool = True
    proctor_tab: bool = True

class VacancyUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    time_per_question: Optional[int] = None
    proctor_face: Optional[bool] = None
    proctor_audio: Optional[bool] = None
    proctor_tab: Optional[bool] = None
    status: Optional[str] = None

class QuestionCreate(BaseModel):
    text: str
    order_num: int = 0
    time_limit: Optional[int] = None

class GenerateQuestionsRequest(BaseModel):
    vacancy_id: int
    description: str
    count: int = 5

@router.get("/")
async def list_vacancies(current_user: dict = Depends(get_current_user)):
    conn = get_db_connection()
    try:
        vacancies = conn.execute(
            """SELECT v.*, COUNT(q.id) as question_count,
               (SELECT COUNT(*) FROM sessions s WHERE s.vacancy_id = v.id) as session_count
               FROM vacancies v
               LEFT JOIN questions q ON q.vacancy_id = v.id
               WHERE v.hr_id = ?
               GROUP BY v.id
               ORDER BY v.created_at DESC""",
            (current_user["sub"],)
        ).fetchall()
        return [dict(v) for v in vacancies]
    finally:
        conn.close()

@router.post("/")
async def create_vacancy(data: VacancyCreate, current_user: dict = Depends(get_current_user)):
    conn = get_db_connection()
    try:
        cursor = conn.execute(
            """INSERT INTO vacancies (hr_id, title, description, time_per_question, proctor_face, proctor_audio, proctor_tab)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (current_user["sub"], data.title, data.description, data.time_per_question,
             1 if data.proctor_face else 0, 1 if data.proctor_audio else 0, 1 if data.proctor_tab else 0)
        )
        conn.commit()
        vacancy = conn.execute("SELECT * FROM vacancies WHERE id=?", (cursor.lastrowid,)).fetchone()
        return dict(vacancy)
    finally:
        conn.close()

@router.get("/{vacancy_id}")
async def get_vacancy(vacancy_id: int, current_user: dict = Depends(get_current_user)):
    conn = get_db_connection()
    try:
        vacancy = conn.execute(
            "SELECT * FROM vacancies WHERE id=? AND hr_id=?",
            (vacancy_id, current_user["sub"])
        ).fetchone()
        if not vacancy:
            raise HTTPException(status_code=404, detail="Vacancy not found")
        
        questions = conn.execute(
            "SELECT * FROM questions WHERE vacancy_id=? ORDER BY order_num, id",
            (vacancy_id,)
        ).fetchall()
        
        result = dict(vacancy)
        result["questions"] = [dict(q) for q in questions]
        return result
    finally:
        conn.close()

@router.put("/{vacancy_id}")
async def update_vacancy(vacancy_id: int, data: VacancyUpdate, current_user: dict = Depends(get_current_user)):
    conn = get_db_connection()
    try:
        vacancy = conn.execute(
            "SELECT * FROM vacancies WHERE id=? AND hr_id=?",
            (vacancy_id, current_user["sub"])
        ).fetchone()
        if not vacancy:
            raise HTTPException(status_code=404, detail="Vacancy not found")
        
        updates = {}
        if data.title is not None: updates["title"] = data.title
        if data.description is not None: updates["description"] = data.description
        if data.time_per_question is not None: updates["time_per_question"] = data.time_per_question
        if data.proctor_face is not None: updates["proctor_face"] = 1 if data.proctor_face else 0
        if data.proctor_audio is not None: updates["proctor_audio"] = 1 if data.proctor_audio else 0
        if data.proctor_tab is not None: updates["proctor_tab"] = 1 if data.proctor_tab else 0
        if data.status is not None: updates["status"] = data.status
        
        if updates:
            set_clause = ", ".join(f"{k}=?" for k in updates.keys())
            conn.execute(
                f"UPDATE vacancies SET {set_clause} WHERE id=?",
                list(updates.values()) + [vacancy_id]
            )
            conn.commit()
        
        return dict(conn.execute("SELECT * FROM vacancies WHERE id=?", (vacancy_id,)).fetchone())
    finally:
        conn.close()

@router.delete("/{vacancy_id}")
async def delete_vacancy(vacancy_id: int, current_user: dict = Depends(get_current_user)):
    conn = get_db_connection()
    try:
        conn.execute("DELETE FROM vacancies WHERE id=? AND hr_id=?", (vacancy_id, current_user["sub"]))
        conn.commit()
        return {"ok": True}
    finally:
        conn.close()

# Questions
@router.get("/{vacancy_id}/questions")
async def get_questions(vacancy_id: int, current_user: dict = Depends(get_current_user)):
    conn = get_db_connection()
    try:
        questions = conn.execute(
            "SELECT * FROM questions WHERE vacancy_id=? ORDER BY order_num, id",
            (vacancy_id,)
        ).fetchall()
        return [dict(q) for q in questions]
    finally:
        conn.close()

@router.post("/{vacancy_id}/questions")
async def add_question(vacancy_id: int, data: QuestionCreate, current_user: dict = Depends(get_current_user)):
    conn = get_db_connection()
    try:
        # Verify ownership
        vacancy = conn.execute("SELECT id FROM vacancies WHERE id=? AND hr_id=?", (vacancy_id, current_user["sub"])).fetchone()
        if not vacancy:
            raise HTTPException(status_code=404, detail="Vacancy not found")
        
        cursor = conn.execute(
            "INSERT INTO questions (vacancy_id, text, order_num, time_limit) VALUES (?, ?, ?, ?)",
            (vacancy_id, data.text, data.order_num, data.time_limit)
        )
        conn.commit()
        q = conn.execute("SELECT * FROM questions WHERE id=?", (cursor.lastrowid,)).fetchone()
        return dict(q)
    finally:
        conn.close()

@router.put("/{vacancy_id}/questions/{question_id}")
async def update_question(vacancy_id: int, question_id: int, data: QuestionCreate, current_user: dict = Depends(get_current_user)):
    conn = get_db_connection()
    try:
        conn.execute(
            "UPDATE questions SET text=?, order_num=?, time_limit=? WHERE id=? AND vacancy_id=?",
            (data.text, data.order_num, data.time_limit, question_id, vacancy_id)
        )
        conn.commit()
        return {"ok": True}
    finally:
        conn.close()

@router.delete("/{vacancy_id}/questions/{question_id}")
async def delete_question(vacancy_id: int, question_id: int, current_user: dict = Depends(get_current_user)):
    conn = get_db_connection()
    try:
        conn.execute("DELETE FROM questions WHERE id=? AND vacancy_id=?", (question_id, vacancy_id))
        conn.commit()
        return {"ok": True}
    finally:
        conn.close()

@router.post("/{vacancy_id}/questions/reorder")
async def reorder_questions(vacancy_id: int, ids: List[int], current_user: dict = Depends(get_current_user)):
    conn = get_db_connection()
    try:
        for i, qid in enumerate(ids):
            conn.execute("UPDATE questions SET order_num=? WHERE id=? AND vacancy_id=?", (i, qid, vacancy_id))
        conn.commit()
        return {"ok": True}
    finally:
        conn.close()

@router.post("/generate-questions")
async def generate_questions(data: GenerateQuestionsRequest, current_user: dict = Depends(get_current_user)):
    """Generate interview questions using Claude or OpenAI API"""
    conn = get_db_connection()
    try:
        # Get API settings
        claude_key = conn.execute("SELECT value FROM app_settings WHERE key='claude_api_key'").fetchone()
        openai_key = conn.execute("SELECT value FROM app_settings WHERE key='openai_api_key'").fetchone()
        
        questions = []
        
        if claude_key and claude_key["value"]:
            questions = await _generate_with_claude(claude_key["value"], data.description, data.count)
        elif openai_key and openai_key["value"]:
            questions = await _generate_with_openai(openai_key["value"], data.description, data.count)
        else:
            # Fallback: generate basic questions without AI
            questions = _generate_fallback_questions(data.description, data.count)
        
        # Save to DB
        saved = []
        existing_count = conn.execute("SELECT COUNT(*) as c FROM questions WHERE vacancy_id=?", (data.vacancy_id,)).fetchone()["c"]
        
        for i, q_text in enumerate(questions):
            cursor = conn.execute(
                "INSERT INTO questions (vacancy_id, text, order_num) VALUES (?, ?, ?)",
                (data.vacancy_id, q_text, existing_count + i)
            )
            conn.commit()
            saved.append({"id": cursor.lastrowid, "text": q_text, "order_num": existing_count + i})
        
        return {"questions": saved}
    finally:
        conn.close()

async def _generate_with_claude(api_key: str, description: str, count: int) -> list:
    prompt = f"""Ты — опытный HR-специалист. Создай {count} вопросов для интервью на основе описания вакансии.

Описание вакансии:
{description}

Требования к вопросам:
- Открытые вопросы (не да/нет)
- Проверяют реальный опыт и навыки
- Разной сложности (от общих к конкретным)
- На русском языке

Верни ТОЛЬКО список вопросов, по одному на строку, без нумерации и лишнего текста."""

    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(
            "https://api.anthropic.com/v1/messages",
            headers={"x-api-key": api_key, "anthropic-version": "2023-06-01", "content-type": "application/json"},
            json={"model": "claude-sonnet-4-20250514", "max_tokens": 1000, "messages": [{"role": "user", "content": prompt}]}
        )
        data = resp.json()
        text = data["content"][0]["text"]
        return [q.strip() for q in text.strip().split("\n") if q.strip()][:count]

async def _generate_with_openai(api_key: str, description: str, count: int) -> list:
    prompt = f"""Ты — опытный HR-специалист. Создай {count} вопросов для интервью на основе описания вакансии.
Описание: {description}
Верни ТОЛЬКО список вопросов, по одному на строку, без нумерации."""

    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(
            "https://api.openai.com/v1/chat/completions",
            headers={"Authorization": f"Bearer {api_key}", "content-type": "application/json"},
            json={"model": "gpt-4o-mini", "messages": [{"role": "user", "content": prompt}], "max_tokens": 1000}
        )
        data = resp.json()
        text = data["choices"][0]["message"]["content"]
        return [q.strip() for q in text.strip().split("\n") if q.strip()][:count]

def _generate_fallback_questions(description: str, count: int) -> list:
    base_questions = [
        "Расскажите о вашем профессиональном опыте, связанном с данной позицией.",
        "Какие ваши сильные стороны помогут вам на этой должности?",
        "Опишите самый сложный проект, над которым вам приходилось работать.",
        "Как вы справляетесь с конфликтными ситуациями в коллективе?",
        "Какие у вас профессиональные цели на ближайшие 2-3 года?",
        "Расскажите о случае, когда вы допустили ошибку. Как вы её исправили?",
        "Как вы организуете свою работу при наличии нескольких срочных задач?",
        "Что вас привлекает в нашей компании?",
        "Опишите ваш идеальный рабочий процесс.",
        "Какие технологии или инструменты вы используете в работе?"
    ]
    return base_questions[:min(count, len(base_questions))]

from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from fastapi.responses import JSONResponse
import os
import shutil
from datetime import datetime
from database import get_db_connection

router = APIRouter()

VIDEOS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "storage", "videos")
SCREENSHOTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "storage", "screenshots")

os.makedirs(VIDEOS_DIR, exist_ok=True)
os.makedirs(SCREENSHOTS_DIR, exist_ok=True)

@router.post("/video")
async def upload_video(
    file: UploadFile = File(...),
    session_id: int = Form(...),
    chunk_index: int = Form(0),
    total_chunks: int = Form(1)
):
    """Upload video recording from interview"""
    if not file.filename:
        raise HTTPException(status_code=400, detail="No file provided")
    
    timestamp = int(datetime.utcnow().timestamp())
    filename = f"{session_id}_{timestamp}.webm"
    filepath = os.path.join(VIDEOS_DIR, filename)
    
    # For chunked uploads, append to file
    if total_chunks > 1 and chunk_index > 0:
        mode = "ab"
    else:
        mode = "wb"
    
    try:
        with open(filepath, mode) as f:
            content = await file.read()
            f.write(content)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to save video: {str(e)}")
    
    # Update DB with video path only on last chunk or single upload
    if chunk_index == total_chunks - 1 or total_chunks == 1:
        conn = get_db_connection()
        try:
            conn.execute(
                "UPDATE sessions SET video_path=? WHERE id=?",
                (f"/storage/videos/{filename}", session_id)
            )
            conn.commit()
        finally:
            conn.close()
    
    return {
        "ok": True,
        "filename": filename,
        "path": f"/storage/videos/{filename}",
        "chunk": chunk_index,
        "total": total_chunks
    }

@router.post("/screenshot")
async def upload_screenshot(
    file: UploadFile = File(...),
    session_id: int = Form(...),
    timestamp_sec: float = Form(...)
):
    """Upload violation screenshot"""
    filename = f"{session_id}_{int(timestamp_sec)}.png"
    filepath = os.path.join(SCREENSHOTS_DIR, filename)
    
    try:
        with open(filepath, "wb") as f:
            content = await file.read()
            f.write(content)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to save screenshot: {str(e)}")
    
    return {"ok": True, "path": f"/storage/screenshots/{filename}"}

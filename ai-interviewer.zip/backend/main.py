from fastapi import FastAPI, HTTPException, Depends, UploadFile, File, Form, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import uvicorn
import os
import sys

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from database import init_db, get_db
from auth import router as auth_router
from vacancies import router as vacancies_router
from sessions import router as sessions_router
from upload import router as upload_router
from settings_routes import router as settings_router
from reports import router as reports_router
from middleware import SecurityMiddleware

app = FastAPI(title="AI Interviewer", version="1.0.0")

# Security middleware
app.add_middleware(SecurityMiddleware)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize DB on startup
@app.on_event("startup")
async def startup():
    init_db()
    # Mark any in-progress sessions as interrupted on restart
    from database import get_db_connection
    conn = get_db_connection()
    conn.execute(
        "UPDATE sessions SET status='interrupted' WHERE status='in_progress'"
    )
    conn.commit()
    conn.close()
    print("✅ Database initialized, interrupted sessions marked")

# Mount routers
app.include_router(auth_router, prefix="/api/auth", tags=["auth"])
app.include_router(vacancies_router, prefix="/api/vacancies", tags=["vacancies"])
app.include_router(sessions_router, prefix="/api/sessions", tags=["sessions"])
app.include_router(upload_router, prefix="/api/upload", tags=["upload"])
app.include_router(settings_router, prefix="/api/settings", tags=["settings"])
app.include_router(reports_router, prefix="/api/reports", tags=["reports"])

# Serve video files
videos_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "storage", "videos")
os.makedirs(videos_path, exist_ok=True)
app.mount("/storage/videos", StaticFiles(directory=videos_path), name="videos")

# Serve frontend
frontend_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "frontend")
app.mount("/static", StaticFiles(directory=frontend_path), name="static")

@app.get("/admin")
@app.get("/admin/{path:path}")
async def admin_page():
    return FileResponse(os.path.join(frontend_path, "admin", "index.html"))

@app.get("/interview/{code}")
async def interview_page(code: str):
    return FileResponse(os.path.join(frontend_path, "interview", "index.html"))

@app.get("/")
async def root():
    return FileResponse(os.path.join(frontend_path, "admin", "index.html"))

@app.get("/health")
async def health():
    return {"status": "ok", "version": "1.0.0"}

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=False, workers=1)

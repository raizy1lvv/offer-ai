from fastapi import APIRouter, HTTPException, Depends, Request
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, EmailStr
import bcrypt
import jwt
import os
from datetime import datetime, timedelta
from database import get_db, get_db_connection

router = APIRouter()
security = HTTPBearer()

JWT_SECRET = os.environ.get("JWT_SECRET", "supersecret-change-in-production-please-1234567890")
JWT_ALGORITHM = "HS256"
JWT_EXPIRY_HOURS = 24 * 7  # 7 days

class RegisterRequest(BaseModel):
    email: str
    password: str
    name: str

class LoginRequest(BaseModel):
    email: str
    password: str

def create_token(user_id: int, email: str, role: str) -> str:
    payload = {
        "sub": str(user_id),
        "email": email,
        "role": role,
        "exp": datetime.utcnow() + timedelta(hours=JWT_EXPIRY_HOURS)
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)

def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)):
    try:
        payload = jwt.decode(credentials.credentials, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")

def get_current_user(token_data: dict = Depends(verify_token)):
    return token_data

@router.post("/register")
async def register(data: RegisterRequest):
    conn = get_db_connection()
    try:
        existing = conn.execute("SELECT id FROM users WHERE email=?", (data.email,)).fetchone()
        if existing:
            raise HTTPException(status_code=400, detail="Email already registered")
        
        if len(data.password) < 6:
            raise HTTPException(status_code=400, detail="Password must be at least 6 characters")
        
        hashed = bcrypt.hashpw(data.password.encode(), bcrypt.gensalt()).decode()
        
        cursor = conn.execute(
            "INSERT INTO users (email, password_hash, name) VALUES (?, ?, ?)",
            (data.email.lower().strip(), hashed, data.name.strip())
        )
        conn.commit()
        
        user_id = cursor.lastrowid
        token = create_token(user_id, data.email, "hr")
        
        return {"token": token, "user": {"id": user_id, "email": data.email, "name": data.name, "role": "hr"}}
    finally:
        conn.close()

@router.post("/login")
async def login(data: LoginRequest):
    conn = get_db_connection()
    try:
        user = conn.execute(
            "SELECT * FROM users WHERE email=? AND is_active=1", 
            (data.email.lower().strip(),)
        ).fetchone()
        
        if not user:
            raise HTTPException(status_code=401, detail="Invalid email or password")
        
        if not bcrypt.checkpw(data.password.encode(), user["password_hash"].encode()):
            raise HTTPException(status_code=401, detail="Invalid email or password")
        
        token = create_token(user["id"], user["email"], user["role"])
        
        return {
            "token": token,
            "user": {"id": user["id"], "email": user["email"], "name": user["name"], "role": user["role"]}
        }
    finally:
        conn.close()

@router.get("/me")
async def me(current_user: dict = Depends(get_current_user)):
    conn = get_db_connection()
    try:
        user = conn.execute("SELECT id, email, name, role FROM users WHERE id=?", (current_user["sub"],)).fetchone()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        return dict(user)
    finally:
        conn.close()

from fastapi import APIRouter, Depends, HTTPException, Response
from database import get_db_connection
from auth import get_current_user
import json

router = APIRouter()

@router.get("/{session_id}/pdf")
async def export_pdf(session_id: int, current_user: dict = Depends(get_current_user)):
    """Generate HTML report (PDF generation happens client-side via browser print)"""
    conn = get_db_connection()
    try:
        session = conn.execute(
            """SELECT s.*, v.title as vacancy_title FROM sessions s
               JOIN vacancies v ON v.id = s.vacancy_id
               WHERE s.id=? AND v.hr_id=?""",
            (session_id, current_user["sub"])
        ).fetchone()
        
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")
        
        violations = conn.execute(
            "SELECT * FROM violations WHERE session_id=? ORDER BY timestamp_sec",
            (session_id,)
        ).fetchall()
        
        answers = conn.execute(
            "SELECT * FROM answers WHERE session_id=? ORDER BY id",
            (session_id,)
        ).fetchall()
        
        s = dict(session)
        v_list = [dict(v) for v in violations]
        a_list = [dict(a) for a in answers]
        
        verdict = s.get("ai_verdict", "Нет данных")
        verdict_color = {"Рекомендован": "#10b981", "Есть сомнения": "#f59e0b", "Вероятно списывание": "#ef4444"}.get(verdict, "#6b7280")
        
        violations_html = ""
        for v in v_list:
            type_labels = {
                "face_absent": "Лицо отсутствует",
                "multiple_faces": "Несколько лиц",
                "tab_switch": "Смена вкладки",
                "audio_noise": "Посторонний звук"
            }
            violations_html += f"""
            <tr>
                <td>{type_labels.get(v['type'], v['type'])}</td>
                <td>{v['timestamp_sec']:.1f}s</td>
                <td>{v['description']}</td>
            </tr>"""
        
        answers_html = ""
        for a in a_list:
            answers_html += f"""
            <div class="answer-block">
                <p class="question">❓ {a['question_text']}</p>
                <p class="answer">💬 {a['answer_text'] or '(нет ответа)'}</p>
                <p class="meta">Длительность: {a['duration_seconds']}с</p>
            </div>"""
        
        html = f"""<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<title>Отчёт об интервью — {s.get('candidate_name', 'Кандидат')}</title>
<style>
  body {{ font-family: Arial, sans-serif; max-width: 900px; margin: 0 auto; padding: 20px; color: #333; }}
  h1 {{ color: #1e293b; border-bottom: 2px solid #e2e8f0; padding-bottom: 10px; }}
  .meta {{ background: #f8fafc; padding: 15px; border-radius: 8px; margin: 20px 0; }}
  .verdict {{ display: inline-block; padding: 8px 16px; border-radius: 6px; color: white; font-weight: bold; background: {verdict_color}; }}
  table {{ width: 100%; border-collapse: collapse; margin: 20px 0; }}
  th, td {{ border: 1px solid #e2e8f0; padding: 10px; text-align: left; }}
  th {{ background: #f1f5f9; font-weight: 600; }}
  .answer-block {{ background: #f8fafc; padding: 15px; margin: 10px 0; border-radius: 8px; border-left: 4px solid #3b82f6; }}
  .question {{ font-weight: bold; color: #1e293b; margin: 0 0 8px 0; }}
  .answer {{ color: #475569; margin: 0 0 5px 0; }}
  .meta {{ font-size: 12px; color: #94a3b8; margin: 0; }}
  @media print {{ button {{ display: none; }} }}
</style>
</head>
<body>
<button onclick="window.print()" style="background:#3b82f6;color:white;border:none;padding:10px 20px;border-radius:6px;cursor:pointer;margin-bottom:20px;">🖨️ Сохранить как PDF</button>
<h1>Отчёт об интервью</h1>
<div class="meta">
  <p><strong>Вакансия:</strong> {s.get('vacancy_title', '-')}</p>
  <p><strong>Кандидат:</strong> {s.get('candidate_name', '-')}</p>
  <p><strong>Email:</strong> {s.get('candidate_email', '-')}</p>
  <p><strong>Начало:</strong> {s.get('started_at', '-')}</p>
  <p><strong>Завершение:</strong> {s.get('finished_at', '-')}</p>
  <p><strong>Статус:</strong> {s.get('status', '-')}</p>
  <p><strong>Вердикт AI:</strong> <span class="verdict">{verdict}</span></p>
</div>

<h2>Нарушения ({len(v_list)})</h2>
{"<p>Нарушений не обнаружено ✅</p>" if not v_list else f'<table><thead><tr><th>Тип</th><th>Время</th><th>Описание</th></tr></thead><tbody>{violations_html}</tbody></table>'}

<h2>Ответы кандидата</h2>
{"<p>Ответов не записано</p>" if not a_list else answers_html}

<p style="margin-top:40px;color:#94a3b8;font-size:12px;">Отчёт сгенерирован системой AI-видеособеседователь</p>
</body>
</html>"""
        
        return Response(content=html, media_type="text/html")
    finally:
        conn.close()

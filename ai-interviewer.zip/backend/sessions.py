from fastapi import APIRouter, HTTPException, Depends, Request
from pydantic import BaseModel
from typing import Optional, List
import secrets
import json
import os
from datetime import datetime
from database import get_db_connection
from auth import get_current_user

router = APIRouter()

VIDEOS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "storage", "videos")
SCREENSHOTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "storage", "screenshots")

class CreateSessionRequest(BaseModel):
    vacancy_id: int
    candidate_name: Optional[str] = None
    candidate_email: Optional[str] = None

class StartSessionRequest(BaseModel):
    candidate_name: str
    consent: bool

class AnswerRequest(BaseModel):
    session_id: int
    question_id: int
    question_text: str
    answer_text: str
    duration_seconds: int

class ViolationRequest(BaseModel):
    session_id: int
    type: str
    timestamp_sec: float
    description: str
    screenshot_b64: Optional[str] = None

class FinishSessionRequest(BaseModel):
    session_id: int
    violations: Optional[list] = []
    answers: Optional[list] = []

@router.post("/create")
async def create_session(data: CreateSessionRequest, current_user: dict = Depends(get_current_user)):
    """HR creates invite link for candidate"""
    conn = get_db_connection()
    try:
        vacancy = conn.execute(
            "SELECT * FROM vacancies WHERE id=? AND hr_id=?",
            (data.vacancy_id, current_user["sub"])
        ).fetchone()
        if not vacancy:
            raise HTTPException(status_code=404, detail="Vacancy not found")
        
        invite_code = secrets.token_urlsafe(16)
        
        cursor = conn.execute(
            """INSERT INTO sessions (vacancy_id, invite_code, candidate_name, candidate_email)
               VALUES (?, ?, ?, ?)""",
            (data.vacancy_id, invite_code, data.candidate_name, data.candidate_email)
        )
        conn.commit()
        
        session_id = cursor.lastrowid
        session = conn.execute("SELECT * FROM sessions WHERE id=?", (session_id,)).fetchone()
        return dict(session)
    finally:
        conn.close()

@router.get("/invite/{code}")
async def get_invite_info(code: str):
    """Public endpoint - candidate gets info about their interview"""
    conn = get_db_connection()
    try:
        session = conn.execute(
            """SELECT s.*, v.title as vacancy_title, v.description as vacancy_description,
               v.time_per_question, v.proctor_face, v.proctor_audio, v.proctor_tab
               FROM sessions s
               JOIN vacancies v ON v.id = s.vacancy_id
               WHERE s.invite_code=?""",
            (code,)
        ).fetchone()
        
        if not session:
            raise HTTPException(status_code=404, detail="Invite link not found")
        
        if session["status"] in ("completed", "interrupted"):
            raise HTTPException(status_code=410, detail="This interview link has already been used")
        
        questions = conn.execute(
            """SELECT q.* FROM questions q
               JOIN vacancies v ON v.id = q.vacancy_id
               WHERE v.id=? ORDER BY q.order_num, q.id""",
            (session["vacancy_id"],)
        ).fetchall()
        
        result = dict(session)
        result["questions"] = [dict(q) for q in questions]
        # Don't expose sensitive HR data
        result.pop("report_json", None)
        return result
    finally:
        conn.close()

@router.post("/start")
async def start_session(data: StartSessionRequest, request: Request):
    """Candidate starts their interview"""
    # We need the invite code - passed as query param or in body
    invite_code = request.query_params.get("code")
    if not invite_code:
        raise HTTPException(status_code=400, detail="Invite code required")
    
    conn = get_db_connection()
    try:
        session = conn.execute(
            "SELECT * FROM sessions WHERE invite_code=?", (invite_code,)
        ).fetchone()
        
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")
        
        if session["status"] not in ("pending",):
            raise HTTPException(status_code=410, detail="Session already started or completed")
        
        if not data.consent:
            raise HTTPException(status_code=400, detail="Consent required")
        
        conn.execute(
            """UPDATE sessions SET status='in_progress', started_at=datetime('now'),
               candidate_name=?, consent_given=1 WHERE invite_code=?""",
            (data.candidate_name, invite_code)
        )
        conn.commit()
        
        return {"session_id": session["id"], "status": "started"}
    finally:
        conn.close()

@router.post("/answer")
async def save_answer(data: AnswerRequest):
    """Save candidate's answer to a question"""
    conn = get_db_connection()
    try:
        conn.execute(
            """INSERT INTO answers (session_id, question_id, question_text, answer_text, duration_seconds)
               VALUES (?, ?, ?, ?, ?)""",
            (data.session_id, data.question_id, data.question_text, data.answer_text, data.duration_seconds)
        )
        conn.commit()
        return {"ok": True}
    finally:
        conn.close()

@router.post("/violation")
async def save_violation(data: ViolationRequest):
    """Save a proctoring violation"""
    conn = get_db_connection()
    try:
        screenshot_path = None
        
        # Save screenshot if provided
        if data.screenshot_b64:
            import base64
            os.makedirs(SCREENSHOTS_DIR, exist_ok=True)
            filename = f"{data.session_id}_{int(data.timestamp_sec)}.png"
            filepath = os.path.join(SCREENSHOTS_DIR, filename)
            try:
                img_data = data.screenshot_b64.split(",")[-1]
                with open(filepath, "wb") as f:
                    f.write(base64.b64decode(img_data))
                screenshot_path = f"/storage/screenshots/{filename}"
            except Exception as e:
                print(f"Screenshot save error: {e}")
        
        conn.execute(
            """INSERT INTO violations (session_id, type, timestamp_sec, description, screenshot_path)
               VALUES (?, ?, ?, ?, ?)""",
            (data.session_id, data.type, data.timestamp_sec, data.description, screenshot_path)
        )
        conn.commit()
        return {"ok": True}
    finally:
        conn.close()

@router.post("/finish")
async def finish_session(data: FinishSessionRequest):
    """Candidate finishes interview"""
    conn = get_db_connection()
    try:
        session = conn.execute("SELECT * FROM sessions WHERE id=?", (data.session_id,)).fetchone()
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")
        
        violations = conn.execute(
            "SELECT * FROM violations WHERE session_id=? ORDER BY timestamp_sec",
            (data.session_id,)
        ).fetchall()
        
        answers = conn.execute(
            "SELECT * FROM answers WHERE session_id=?",
            (data.session_id,)
        ).fetchall()
        
        # Generate AI verdict based on violations
        verdict = _calculate_verdict(violations, answers)
        
        report = {
            "session_id": data.session_id,
            "finished_at": datetime.utcnow().isoformat(),
            "violations": [dict(v) for v in violations],
            "answers_count": len(answers),
            "verdict": verdict
        }
        
        conn.execute(
            """UPDATE sessions SET status='completed', finished_at=datetime('now'),
               report_json=?, ai_verdict=? WHERE id=?""",
            (json.dumps(report, ensure_ascii=False), verdict["label"], data.session_id)
        )
        conn.commit()
        
        return {"ok": True, "verdict": verdict}
    finally:
        conn.close()

def _calculate_verdict(violations, answers) -> dict:
    """Simple rule-based verdict calculation"""
    violation_list = [dict(v) for v in violations]
    
    face_absent = sum(1 for v in violation_list if v["type"] == "face_absent")
    multiple_faces = sum(1 for v in violation_list if v["type"] == "multiple_faces")
    tab_switch = sum(1 for v in violation_list if v["type"] == "tab_switch")
    audio_noise = sum(1 for v in violation_list if v["type"] == "audio_noise")
    
    score = 100
    score -= face_absent * 5
    score -= multiple_faces * 20
    score -= tab_switch * 10
    score -= audio_noise * 3
    score = max(0, score)
    
    if score >= 85:
        label = "Рекомендован"
        color = "green"
    elif score >= 60:
        label = "Есть сомнения"
        color = "yellow"
    else:
        label = "Вероятно списывание"
        color = "red"
    
    return {
        "label": label,
        "color": color,
        "score": score,
        "violations_count": len(violation_list),
        "details": {
            "face_absent_count": face_absent,
            "multiple_faces_count": multiple_faces,
            "tab_switch_count": tab_switch,
            "audio_noise_count": audio_noise
        }
    }

# HR admin routes
@router.get("/")
async def list_sessions(
    vacancy_id: Optional[int] = None,
    status: Optional[str] = None,
    current_user: dict = Depends(get_current_user)
):
    conn = get_db_connection()
    try:
        query = """SELECT s.*, v.title as vacancy_title,
                   (SELECT COUNT(*) FROM violations vio WHERE vio.session_id = s.id) as violation_count
                   FROM sessions s
                   JOIN vacancies v ON v.id = s.vacancy_id
                   WHERE v.hr_id = ?"""
        params = [current_user["sub"]]
        
        if vacancy_id:
            query += " AND s.vacancy_id = ?"
            params.append(vacancy_id)
        if status:
            query += " AND s.status = ?"
            params.append(status)
        
        query += " ORDER BY s.created_at DESC"
        
        sessions = conn.execute(query, params).fetchall()
        return [dict(s) for s in sessions]
    finally:
        conn.close()

@router.get("/{session_id}")
async def get_session(session_id: int, current_user: dict = Depends(get_current_user)):
    conn = get_db_connection()
    try:
        session = conn.execute(
            """SELECT s.*, v.title as vacancy_title, v.time_per_question,
               v.proctor_face, v.proctor_audio, v.proctor_tab
               FROM sessions s
               JOIN vacancies v ON v.id = s.vacancy_id
               WHERE s.id=? AND v.hr_id=?""",
            (session_id, current_user["sub"])
        ).fetchone()
        
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")
        
        violations = conn.execute(
            "SELECT * FROM violations WHERE session_id=? ORDER BY timestamp_sec",
            (session_id,)
        ).fetchall()
        
        answers = conn.execute(
            "SELECT * FROM answers WHERE session_id=? ORDER BY id",
            (session_id,)
        ).fetchall()
        
        result = dict(session)
        result["violations"] = [dict(v) for v in violations]
        result["answers"] = [dict(a) for a in answers]
        
        if result.get("report_json"):
            try:
                result["report"] = json.loads(result["report_json"])
            except:
                result["report"] = None
        
        return result
    finally:
        conn.close()

@router.delete("/{session_id}")
async def delete_session(session_id: int, current_user: dict = Depends(get_current_user)):
    conn = get_db_connection()
    try:
        session = conn.execute(
            """SELECT s.* FROM sessions s JOIN vacancies v ON v.id = s.vacancy_id
               WHERE s.id=? AND v.hr_id=?""",
            (session_id, current_user["sub"])
        ).fetchone()
        
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")
        
        # Delete video file if exists
        if session["video_path"]:
            video_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", session["video_path"].lstrip("/"))
            if os.path.exists(video_file):
                os.remove(video_file)
        
        conn.execute("DELETE FROM violations WHERE session_id=?", (session_id,))
        conn.execute("DELETE FROM answers WHERE session_id=?", (session_id,))
        conn.execute("DELETE FROM sessions WHERE id=?", (session_id,))
        conn.commit()
        
        return {"ok": True}
    finally:
        conn.close()

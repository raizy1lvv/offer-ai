from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional
from database import get_db_connection
from auth import get_current_user

router = APIRouter()

class SettingsUpdate(BaseModel):
    claude_api_key: Optional[str] = None
    openai_api_key: Optional[str] = None
    smtp_host: Optional[str] = None
    smtp_port: Optional[str] = None
    smtp_user: Optional[str] = None
    smtp_pass: Optional[str] = None

@router.get("/")
async def get_settings(current_user: dict = Depends(get_current_user)):
    conn = get_db_connection()
    try:
        rows = conn.execute("SELECT key, value FROM app_settings").fetchall()
        settings = {}
        for row in rows:
            key = row["key"]
            value = row["value"]
            # Mask API keys
            if "key" in key.lower() or "pass" in key.lower():
                value = "*" * 8 + value[-4:] if len(value) > 4 else "****"
            settings[key] = value
        return settings
    finally:
        conn.close()

@router.put("/")
async def update_settings(data: SettingsUpdate, current_user: dict = Depends(get_current_user)):
    conn = get_db_connection()
    try:
        updates = data.dict(exclude_none=True)
        for key, value in updates.items():
            if value:  # Only save non-empty values
                conn.execute(
                    "INSERT OR REPLACE INTO app_settings (key, value, updated_at) VALUES (?, ?, datetime('now'))",
                    (key, value)
                )
        conn.commit()
        return {"ok": True}
    finally:
        conn.close()

@router.get("/has-ai-key")
async def has_ai_key():
    """Check if any AI API key is configured (public endpoint)"""
    conn = get_db_connection()
    try:
        claude = conn.execute("SELECT value FROM app_settings WHERE key='claude_api_key'").fetchone()
        openai = conn.execute("SELECT value FROM app_settings WHERE key='openai_api_key'").fetchone()
        return {
            "has_claude": bool(claude and claude["value"]),
            "has_openai": bool(openai and openai["value"]),
            "has_any": bool((claude and claude["value"]) or (openai and openai["value"]))
        }
    finally:
        conn.close()

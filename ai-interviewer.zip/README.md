# 🎙️ AI Видеособеседователь с прокторингом

Система для проведения автоматических видеоинтервью с контролем честности (прокторингом).

---

## 📦 Что умеет система

- **Кандидат** переходит по ссылке, разрешает доступ к камере/микрофону и проходит интервью с AI-ведущим
- **AI** задаёт вопросы голосом и записывает ответы
- **Прокторинг**: контроль присутствия лица, переключения вкладок, посторонних звуков
- **HR** видит все сессии, видеозаписи, нарушения и AI-вердикт ("Рекомендован" / "Есть сомнения" / "Вероятно списывание")
- **Генерация вопросов** через Claude AI или OpenAI по описанию вакансии

---

## 🚀 Быстрый старт (Docker — рекомендуется)

### Шаг 1. Установите Docker

Откройте терминал и выполните:

```bash
# Ubuntu/Debian
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER
# Перезайдите в систему после этой команды
```

На Windows/Mac — скачайте [Docker Desktop](https://www.docker.com/products/docker-desktop/).

### Шаг 2. Скачайте проект

```bash
git clone https://github.com/YOUR_REPO/ai-interviewer.git
cd ai-interviewer
```

Или просто скопируйте папку с файлами на сервер.

### Шаг 3. Запустите одной командой

```bash
docker-compose up -d
```

### Шаг 4. Откройте браузер

Перейдите на: **http://localhost:8000**

Зарегистрируйтесь — введите имя, email, пароль. Готово!

---

## 🖥️ Запуск без Docker (Ubuntu 22.04)

### Шаг 1. Установите Python 3.11

```bash
sudo apt update
sudo apt install -y python3.11 python3.11-pip python3.11-venv
```

### Шаг 2. Создайте виртуальное окружение

```bash
cd ai-interviewer
python3.11 -m venv venv
source venv/bin/activate
```

### Шаг 3. Установите зависимости

```bash
pip install -r backend/requirements.txt
```

### Шаг 4. Запустите приложение

```bash
python backend/main.py
```

Откройте браузер: **http://localhost:8000**

### Работа 24/7 через PM2 (Process Manager)

```bash
# Установите PM2
sudo apt install -y nodejs npm
sudo npm install -g pm2

# Запустите приложение через PM2
pm2 start "source venv/bin/activate && python backend/main.py" --name ai-interviewer --interpreter bash

# Автозапуск при перезагрузке сервера
pm2 startup
pm2 save
```

Управление:
```bash
pm2 status          # статус
pm2 logs ai-interviewer   # логи
pm2 restart ai-interviewer  # перезапуск
```

---

## ☁️ Деплой на бесплатный хостинг

### Вариант 1: Railway.app (проще всего)

1. Зарегистрируйтесь на [railway.app](https://railway.app)
2. Нажмите **New Project → Deploy from GitHub**
3. Подключите ваш GitHub репозиторий с проектом
4. Railway автоматически обнаружит `Dockerfile` и запустит приложение
5. В разделе **Settings → Domains** нажмите **Generate Domain**
6. Ваш сайт будет доступен по адресу типа `https://ai-interviewer-xxx.up.railway.app`

> ⚠️ Бесплатный план Railway: 500 часов/месяц. Для постоянной работы нужен платный план ($5/мес).

### Вариант 2: Oracle Cloud Always Free

Oracle предоставляет **навсегда бесплатный** сервер VM (2 CPU, 1 GB RAM).

1. Зарегистрируйтесь на [cloud.oracle.com](https://cloud.oracle.com) (нужна карта)
2. Создайте VM instance: **Compute → Instances → Create Instance**
   - Shape: VM.Standard.E2.1.Micro (Always Free)
   - OS: Ubuntu 22.04
3. Подключитесь по SSH:
   ```bash
   ssh ubuntu@YOUR_SERVER_IP
   ```
4. Установите Docker и запустите проект (см. раздел "Быстрый старт" выше)
5. Откройте порт 8000 в настройках файрвола Oracle:
   - Compute → Instances → ваш сервер → Virtual Cloud Network → Security Lists → Add Ingress Rule
   - Source: 0.0.0.0/0, Port: 8000

---

## 🤖 Настройка AI для генерации вопросов

### Получить ключ Claude (Anthropic)

1. Зайдите на [console.anthropic.com](https://console.anthropic.com)
2. Зарегистрируйтесь
3. Перейдите в раздел **API Keys → Create Key**
4. Скопируйте ключ (начинается с `sk-ant-...`)

### Получить ключ OpenAI

1. Зайдите на [platform.openai.com](https://platform.openai.com)
2. Зарегистрируйтесь
3. Перейдите в раздел **API Keys → Create new secret key**
4. Скопируйте ключ (начинается с `sk-...`)

### Вставить ключ в систему

1. Откройте панель HR: `http://ваш-сервер/admin`
2. Войдите в аккаунт
3. В левом меню нажмите **⚙️ Настройки**
4. Вставьте ключ в поле "Claude API Key" или "OpenAI API Key"
5. Нажмите **Сохранить**

---

## 💼 Создание первой вакансии и отправка ссылки

### Шаг 1. Создайте вакансию

1. В панели HR нажмите **💼 Вакансии → + Создать вакансию**
2. Введите название (например: "Python Developer")
3. Введите описание (обязанности, требования, стек)
4. Нажмите **✨ Генерировать AI** — система создаст 5 вопросов автоматически
5. Можно добавить свои вопросы вручную
6. Настройте время на ответ и параметры прокторинга
7. Нажмите **Сохранить**

### Шаг 2. Создайте ссылку для кандидата

1. Найдите вакансию в списке
2. Нажмите кнопку **📩 Пригласить**
3. Введите имя и email кандидата (необязательно)
4. Нажмите **Создать ссылку**
5. Скопируйте ссылку и отправьте кандидату

### Шаг 3. Просмотр результатов

1. После прохождения интервью откройте **🎬 Сессии**
2. Найдите сессию кандидата и нажмите **👁️ Просмотр**
3. Смотрите видеозапись, нарушения и транскрипцию ответов
4. Нажмите **📄 PDF отчёт** для выгрузки

---

## 🧹 Автоматическая очистка старых видео

Добавьте задание в cron (запускать каждую ночь в 2:00):

```bash
crontab -e
```

Добавьте строку:
```
0 2 * * * cd /path/to/ai-interviewer && python cleanup.py >> /var/log/ai-interviewer-cleanup.log 2>&1
```

По умолчанию удаляются видео старше **30 дней**.

---

## 🔒 Безопасность

- Все пароли хранятся в зашифрованном виде (bcrypt)
- Ссылки для кандидатов — одноразовые (случайный код)
- Ссылка блокируется после прохождения или прерывания интервью
- JWT токены для авторизации HR
- Заголовки безопасности (XSS, clickjacking защита)

**В production обязательно:**
```bash
# Установите JWT_SECRET в переменную окружения
export JWT_SECRET="ваш-длинный-случайный-секрет-минимум-32-символа"
```

---

## 📁 Структура проекта

```
ai-interviewer/
├── backend/
│   ├── main.py           # Главный файл FastAPI
│   ├── database.py       # Настройка SQLite
│   ├── auth.py           # Авторизация JWT
│   ├── vacancies.py      # Управление вакансиями
│   ├── sessions.py       # Управление сессиями
│   ├── upload.py         # Загрузка видео
│   ├── reports.py        # Генерация отчётов
│   ├── settings_routes.py # API ключи
│   ├── middleware.py     # Безопасность
│   └── requirements.txt  # Python зависимости
├── frontend/
│   ├── admin/index.html  # Панель HR
│   └── interview/index.html # Страница кандидата
├── storage/
│   ├── videos/           # Видеозаписи интервью
│   └── screenshots/      # Скриншоты нарушений
├── data/
│   └── interviewer.db    # База данных SQLite
├── Dockerfile
├── docker-compose.yml
├── cleanup.py            # Очистка старых файлов
└── README.md
```

---

## ❓ Частые вопросы

**Q: Кандидат говорит, что не слышит вопросы**
A: Синтез речи работает через браузер. Скажите кандидату проверить, что звук не выключен. Лучше всего работает Chrome.

**Q: Видео не записывается**
A: Убедитесь, что папка `storage/videos/` существует и доступна для записи. В Docker это делается автоматически.

**Q: Как переключиться на PostgreSQL?**
A: Замените в `database.py` строку подключения на:
```python
import psycopg2
conn = psycopg2.connect(os.environ.get("DATABASE_URL"))
```
И установите `pip install psycopg2-binary`.

**Q: Детекция лица не работает точно**
A: Текущая реализация использует упрощённый анализ тона кожи через Canvas API. Для более точной детекции подключите [face-api.js](https://github.com/justadudewhohacks/face-api.js):
```html
<script src="https://cdn.jsdelivr.net/npm/face-api.js@0.22.2/dist/face-api.min.js"></script>
```
Смотрите комментарии в коде `interview/index.html`.

**Q: Как добавить S3 для хранения видео?**
A: В `upload.py` замените запись файла на:
```python
import boto3
s3 = boto3.client('s3', aws_access_key_id=..., aws_secret_access_key=...)
s3.upload_fileobj(file.file, BUCKET_NAME, filename)
```

---

## 📞 Поддержка

При возникновении проблем проверьте логи:
```bash
# Docker
docker-compose logs -f

# PM2
pm2 logs ai-interviewer
```
